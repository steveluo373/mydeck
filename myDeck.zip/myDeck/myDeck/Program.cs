﻿using System;
using myDeck.Models;

namespace myDeck
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Args lenth : " + args.Length);
            Deck deck = new Deck();
            deck.CreateDeck();
            Console.WriteLine("There are " + deck.cards.Count + " cards");
            Console.WriteLine("Now Shuffle card...");
            deck.ShuffleDeck();
            for(int i=0;i<deck.cards.Count;i++)
            {
                Console.Write(deck.cards[i].rank + "," + deck.cards[i].suit + " ");
            }
            Console.WriteLine("");
            Console.WriteLine("Now SortBy Rank");
            deck.SortBy("R");
            for (int i = 0; i < deck.cards.Count; i++)
            {
                Console.Write(deck.cards[i].rank + "," + deck.cards[i].suit + " ");
            }
            Console.WriteLine("");
            Console.WriteLine("Now SortBy Suit");
            deck.SortBy("S");
            for (int i = 0; i < deck.cards.Count; i++)
            {
                Console.Write(deck.cards[i].rank + "," + deck.cards[i].suit + " ");
            }
            Console.WriteLine("");
            Console.WriteLine("Now Deal One Card - 3rd one ");
            deck.DealOneCard(3);
            for (int i = 0; i < deck.cards.Count; i++)
            {
                Console.Write(deck.cards[i].rank + "," + deck.cards[i].suit + " ");
            }

            Console.WriteLine("");
            Console.WriteLine("Now Deal many Cards - take 4 cards ");
            deck.DealCards(4);
            for (int i = 0; i < deck.cards.Count; i++)
            {
                Console.Write(deck.cards[i].rank + "," + deck.cards[i].suit + " ");
            }


        }
    }
}
