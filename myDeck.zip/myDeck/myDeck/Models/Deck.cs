﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace myDeck.Models
{
    class Deck
    {
        public List<Card> cards { get; set; }
        public Deck()
        {
            this.cards = new List<Card>();
        }

        public void CreateDeck()
        {
            this.cards = Enumerable.Range(1, 4).SelectMany(s => Enumerable.Range(1, 13)
             .Select(r => new Card()
             {
                 suit = (Suit)s,
                 rank = (Rank)r
             })).ToList();

               
        }

        public void ShuffleDeck()
        {
            this.cards = cards.OrderBy(c => Guid.NewGuid()).ToList();
        }

        public void SortBy(string type)
        {
            if(type.Equals("R"))
            {
                this.cards = cards.OrderBy(c => c.rank).ToList();
            }
            else
            {
                this.cards = cards.OrderBy(c => c.suit).ToList();
            }
        }

        public Card DealOneCard(int i)
        {
            var card = cards.ElementAt<Card>(i);
            cards.Remove(card);
            return card;

        }

        public  IEnumerable<Card> DealCards(int count)
        {
            var cardss = cards.Take(count);
            var selCards = cardss as Card[] ?? cardss.ToArray();
            cards.RemoveAll(selCards.Contains);
            return selCards;
        }


    }
}
