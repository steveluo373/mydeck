﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace myDeck.Models
{
    class Card
    {
        public Suit suit { get; set; }
        public Rank rank { get; set; }
    }
}
